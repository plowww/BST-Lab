/*
	B i n a r y S e a r c h T r e e
	===============================
 */

import java.awt.*;
import java.awt.event.*;

//By Kevin Gomes and Max Frank
//04/20/2016

public class BinarySearchTree extends BinaryTree
{
	private final							//	Defines the size of a basic cell
	int SIZE = Element.HEIGHT;	//		(for drawing purposes)

	//
	//	C o n s t r u c t o r s
	//	=======================
	//
	public BinarySearchTree()
	{
		super();							//	In either case,
	}

	public BinarySearchTree(int x, int y)
	{
		super(x, y);						//		we refer to the base class
	}

	//
	//	Adds one element to the tree.
	//
	protected void add(Object someItem)
	{
		Node placeHolder = new Node();		//	We instantiate a node,

		placeHolder.setItem(someItem);		//		we fill it with the given item,

		root = add(placeHolder, root);		//		and we add the node to the tree
	}

	//
	//	Adds a given node to a given sub-tree.
	//	The node is assumed to contain a (Comparable) item.
	//	Returns the "modified" tree, with the added node.
	//
	private Node add(Node someNode, Node someRoot)
	{
		Node result;						//	To hold the "modified" tree

		if (someRoot == null) {				//	If the sub-tree is empty
			someNode.setRight(null);
			someNode.setLeft(null);
			result = someNode;				//		it will contain that single node
		}
		else {								//	Otherwise
			if (((Comparable) (someNode.getItem())).compareTo(someRoot.getItem()) < 0) {
				Node leftSubTree = add(someNode, someRoot.getLeft());
				someRoot.setLeft(leftSubTree);
			}
			else {
				Node rightSubTree = add(someNode, someRoot.getRight());
				someRoot.setRight(rightSubTree);
			}
			result = someRoot;				//	The root has not changed
		}

		return result;						//	We return the "modified" tree
	}

	//
	//	Removes (i.e., returns and deletes) the smallest element from the tree
	//		(if there is any element).
	//
	public Object remove() throws BinaryTreeException
	{
		//	If there is nothing to remove
		if (isEmpty())						//		we have a problem!
			throw new BinaryTreeException("Empty binary tree");

		Object result;						//	Our result
		//		is the smallest in the tree
		result = getSmallest(root);			//	We get it,
		root = deleteSmallest(root);		//		then we delete it

		return result;						//	Voil�!
	}

	//
	//	The following method determines (and returns) the smallest item stored in
	//		the tree.
	//
	//	Note:  It is assumed that the given tree is not empty.
	//
	private Object getSmallest(Node someRoot)
	{
		Object result = someRoot.getItem(); //If we only have one, this
		//ensures we have the smallest, as the first and last is the smallest.

		if (someRoot.getLeft() != null) //Do not want a null root.
			getSmallest(someRoot.getLeft()); //Go through method until we get to the last one.

		/*******************************************************************************
		 *
		 *		This is just the right place for your getSmallest method.
		 *
		 *		Recursion is required, but it also seems like a good choice for
		 *	your implementation.
		 *
		 *******************************************************************************/
		return result;
	}

	//
	//	The following method deletes the smallest item stored in the tree.
	//
	//	It returns the resulting tree.
	//
	//	Note:  It is assumed that the given tree is not empty.
	//
	private Node deleteSmallest(Node someRoot)
	{
		Node result = someRoot; //In case we have one,
		//and for recursion.
		
		if (someRoot.getLeft() == null)
			return someRoot.getRight(); //if nothing at left, we have smallest.
		//This makes sure we have the right guy attached.
		else
		{
			result.setLeft(deleteSmallest(someRoot.getLeft()));
			//Recursively go through the method, setting the left to the method call.
			return result;
		}
		

		/*******************************************************************************
		 *
		 *		This is just the right place for your deleteSmallest method.
		 *
		 *		Again, recursion is required, and it still seems like a good choice
		 *	for your implementation.
		 *
		 *******************************************************************************/
	}
}